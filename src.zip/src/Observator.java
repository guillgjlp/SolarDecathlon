
public interface Observator {
	
	public void actualise(Observable o); 

}
